package com.quickblox.q_municate.utils.listeners;

public interface ChatUIHelperListener {

    void onScreenResetPossibilityPerformLogout(boolean canPerformLogout);
}