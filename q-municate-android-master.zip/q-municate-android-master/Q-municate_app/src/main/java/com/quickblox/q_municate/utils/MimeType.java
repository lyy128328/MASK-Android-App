package com.quickblox.q_municate.utils;

public interface MimeType {

    String IMAGE_MIME = "image/*";
    String STREAM_MIME = "application/octet-stream";
}