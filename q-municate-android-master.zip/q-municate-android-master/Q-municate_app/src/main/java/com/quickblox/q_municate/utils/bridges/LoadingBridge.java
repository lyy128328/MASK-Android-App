package com.quickblox.q_municate.utils.bridges;

public interface LoadingBridge {

    void showProgress();

    void hideProgress();

    void showActionBarProgress();

    void hideActionBarProgress();
}