package com.quickblox.q_municate.utils.listeners;

public interface SelectUsersListener {

    void onSelectedUsersChanged(int count, String fullNames);
}