package com.quickblox.q_municate_core.models;

public enum StartConversationReason {
    INCOME_CALL_FOR_ACCEPTION,
    OUTCOME_CALL_MADE;
}