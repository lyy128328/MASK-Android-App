package com.quickblox.q_municate_core.qb.helpers;

import android.content.Context;

public abstract class BaseHelper {

    protected Context context;

    public BaseHelper(Context context) {
        this.context = context;
    }
}