package com.moez.QKSMS.receiver;

public class QKIntent {
    public static final String ACTION_ANALYTICS_REPORT = "com.moez.QKSMS.action.analytics_report";
}
