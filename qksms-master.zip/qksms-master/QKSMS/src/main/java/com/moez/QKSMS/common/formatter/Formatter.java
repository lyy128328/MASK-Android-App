package com.moez.QKSMS.common.formatter;

public interface Formatter {
    String format(String text);
}
